public class Pacman {

    private int x, y;
    private int startX, startY;
    private Direction direction;

    public Pacman(int x, int y) {
        this.x = x;
        this.y = y;
        this.startX = x;
        this.startY = y;
        this.direction = Direction.NONE;
    }

    public void move(int[][] level) {

        int newX = x;
        int newY = y;

        switch (direction) {
            case UP:    newY--; break;
            case DOWN:  newY++; break;
            case LEFT:  newX--; break;
            case RIGHT: newX++; break;
            case NONE:  return;
        }

        if (level[newY][newX] != 1) {
            x = newX;
            y = newY;
        }
    }

    public void setDirection(Direction dir) {
        this.direction = dir;
    }

    public void resetPosition() {
        x = startX;
        y = startY;
        direction = Direction.NONE;
    }

    public int getX() { return x; }
    public int getY() { return y; }
}
