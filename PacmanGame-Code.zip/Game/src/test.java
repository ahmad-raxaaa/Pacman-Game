public class test
{
    static void main(String[] args)
    {
//Food Check
//        Food nfood=new Food(2,5,10);
//        System.out.println(nfood.getPoints());
//        System.out.println(nfood.getX());
//        System.out.println(nfood.getY());

    }
}
