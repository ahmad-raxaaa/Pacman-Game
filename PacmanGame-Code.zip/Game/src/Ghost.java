import java.util.Random;

public class Ghost
{
    private int x;
    private int y;
    private int startX;
    private int startY;
    private Random random;

    public Ghost(int x, int y)
    {
        this.x = x;
        this.y = y;
        this.startX = x;
        this.startY = y;
        this.random = new Random();
    }

    public void move(int [][] level)
    {
        Direction [] directions = {
                Direction.UP,Direction.DOWN,
                Direction.LEFT,Direction.RIGHT
        };
        Direction newdirection=directions[random.nextInt(3)];

        int newX=x;
        int newY=y;

        if (level[newX][newY]!=1)
        {
            x = newX;
            y = newY;
        }
        switch (newdirection)
        {
            case RIGHT: newX++; break;
            case LEFT: newX--; break;
            case DOWN: newY--; break;
            case UP: newY++; break;

        }

    }

    public void resetposition()
    {
        x = startX;
        y = startY;
    }
    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }
}
