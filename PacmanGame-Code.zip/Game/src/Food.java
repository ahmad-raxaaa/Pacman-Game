public class Food
{
    private int x;
    private int y;
    private int points;

    public Food(int x, int y, int points)
    {
        this.x = x;
        this.y = y;
        this.points = points;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public int getPoints()
    {
        return points;
    }
}
