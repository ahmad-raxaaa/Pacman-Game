import java.util.Scanner;

public class Game {
    private GameBoard gameBoard;
    private Scanner scanner;

    public Game() {
        gameBoard = new GameBoard();
        scanner = new Scanner(System.in);
    }

    public void start() {
        // Welcome screen
        System.out.println("=================================");
        System.out.println("           PACMAN GAME           ");
        System.out.println("=================================");
        System.out.println(" How to Play:");
        System.out.println("  • Use W/A/S/D to move Pacman");
        System.out.println("  • Eat all dots (·) to win");
        System.out.println("  • Avoid ghosts (G)");
        System.out.println("  • You have 3 lives");
        System.out.println("Press ENTER to start...");
        scanner.nextLine();

        while (gameBoard.isGameRunning()) {

            gameBoard.display();


            if (gameBoard.isGameWon()) {
                System.out.println("==================================");
                System.out.println("          YOU WIN!          ");
                System.out.println("    Final Score: " + String.format("%4d", gameBoard.getScore()));
                System.out.println("==================================");
                break;
            }

            System.out.print("Move: ");
            String input = scanner.nextLine().toLowerCase();

            switch (input) {
                case "w":
                    gameBoard.setPacmanDirection(Direction.UP);
                    break;
                case "s":
                    gameBoard.setPacmanDirection(Direction.DOWN);
                    break;
                case "a":
                    gameBoard.setPacmanDirection(Direction.LEFT);
                    break;
                case "d":
                    gameBoard.setPacmanDirection(Direction.RIGHT);
                    break;
                case "q":
                    System.out.println("Game ended. Final Score: " + gameBoard.getScore());
                    return;
                default:
                    System.out.println("Invalid! Use W/A/S/D or Q");
                    continue;
            }

            gameBoard.update();
        }

        if (!gameBoard.isGameRunning()) {
            System.out.println("==================================");
            System.out.println("         GAME OVER!         ");
            System.out.println("Final Score: " + String.format("%4d", gameBoard.getScore()));
            System.out.println("==================================");
        }

        scanner.close();
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.start();
    }
}