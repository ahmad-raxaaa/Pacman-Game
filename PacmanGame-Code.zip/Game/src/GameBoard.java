import java.util.ArrayList;
import java.util.Scanner;

public class GameBoard {

    private static final int WIDTH = 20;
    private static final int HEIGHT = 17;

    private Pacman pacman;
    private ArrayList<Ghost> ghosts;
    private ArrayList<Food> foods;

    private int score;
    private int lives;
    private boolean gameRunning;

    // 1 = wall, 0 = empty path, 2 = food
    private int[][] level = {
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,2,1,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,1,1,1,1,1,2,1,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,1},
            {1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,1,1,1,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,1},
            {1,2,1,2,1,2,1,1,1,2,1,2,1,1,1,1,1,2,2,1},
            {1,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {1,2,1,2,2,2,2,2,2,2,2,2,2,2,1,1,2,1,2,1},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    };

    public GameBoard() {

        pacman = new Pacman(9, 15);

        ghosts = new ArrayList<>();
        ghosts.add(new Ghost(9, 9));
        ghosts.add(new Ghost(10, 9));
        ghosts.add(new Ghost(8, 10));
        ghosts.add(new Ghost(10, 10));


        foods = new ArrayList<>();
        for (int row = 0; row < HEIGHT; row++) {
            for (int col = 0; col < WIDTH; col++) {
                if (level[row][col] == 2) {
                    foods.add(new Food(col, row, 10));
                }
            }
        }

        score = 0;
        lives = 3;
        gameRunning = true;
    }


    public void display() {

        for (int row = 0; row < HEIGHT; row++) {
            for (int col = 0; col < WIDTH; col++) {

                if (level[row][col] == 1) {
                    System.out.print("#");  // Wall
                }
                else if (pacman.getX() == col && pacman.getY() == row) {
                    System.out.print("C");  // Pacman
                }
                else if (isGhostAt(col, row)) {
                    System.out.print("G");  // Ghost
                }
                else if (isFoodAt(col, row)) {
                    System.out.print("·");  // Food
                }
                else {
                    System.out.print(" ");  // Empty
                }
            }
            System.out.println();
        }

        System.out.println("====================================");
        System.out.println("  Score: " + score + "          Lives: " + lives);
        System.out.println("  Controls: W=Up  S=Down  A=Left  D=Right");
        System.out.println("  Press Q to quit");
        System.out.println("=====================================");
    }

    private boolean isGhostAt(int x, int y) {
        for (Ghost ghost : ghosts) {
            if (ghost.getX() == x && ghost.getY() == y) {
                return true;
            }
        }
        return false;
    }

    private boolean isFoodAt(int x, int y) {
        for (Food food : foods) {
            if (food.getX() == x && food.getY() == y) {
                return true;
            }
        }
        return false;
    }

    public void update() {
        pacman.move(level);
        checkFoodCollision();

        for (Ghost ghost : ghosts) {
            ghost.move(level);
        }

        checkGhostCollision();
    }

    private void checkFoodCollision() {
        Food foodToRemove = null;

        for (Food food : foods) {
            if (food.getX() == pacman.getX() && food.getY() == pacman.getY()) {
                score += food.getPoints();
                foodToRemove = food;
                break;
            }
        }

        if (foodToRemove != null) {
            foods.remove(foodToRemove);
        }
    }

    private void checkGhostCollision() {
        for (Ghost ghost : ghosts) {
            if (ghost.getX() == pacman.getX() && ghost.getY() == pacman.getY()) {
                lives--;

                if (lives <= 0) {
                    gameRunning = false;
                } else {
                    resetPositions();
                }
                break;
            }
        }
    }

    private void resetPositions() {
        pacman.resetPosition();
        for (Ghost ghost : ghosts) {
            ghost.resetposition();
        }
    }

    public void setPacmanDirection(Direction dir) {
        pacman.setDirection(dir);
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public boolean isGameWon() {
        return foods.isEmpty();
    }

    public int getScore() {
        return score;
    }
}